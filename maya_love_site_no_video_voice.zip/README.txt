Maya Love Site — custom message update
- Shortened the opening romantic note.
- Replaced the closing confession with the exact text supplied by the user.
- Replaced the video and audio with the newly uploaded files.
- Keep index.html and the assets folder together when uploading.
